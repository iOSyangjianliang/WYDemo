//
//  Model.h
//  FMDB数据库使用
//
//  Created by 杨建亮 on 2018/5/22.
//  Copyright © 2018年 yangjianliang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDB.h"

@interface Model : NSObject
- (instancetype)initWithSet:(FMResultSet *)set;

//数据库存储id
@property(nonatomic, assign)NSInteger tabId;
@property(nonatomic, strong)NSString *userNick;
@property(nonatomic, strong)NSString *collectionURL;
@property(nonatomic, strong)NSString *collectionTIME;
@property(nonatomic, strong)NSString *collectiontext;
//用户的id
@property(nonatomic, assign)NSInteger userID;




@end
