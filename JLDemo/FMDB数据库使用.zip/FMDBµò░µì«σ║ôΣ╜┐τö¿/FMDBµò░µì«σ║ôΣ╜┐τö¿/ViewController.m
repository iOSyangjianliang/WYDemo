//
//  ViewController.m
//  FMDB数据库使用
//
//  Created by 杨建亮 on 2018/5/22.
//  Copyright © 2018年 yangjianliang. All rights reserved.
//

#import "ViewController.h"
#import "Model.h"
#import "PFFMDBManager.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    Model *model = [[Model alloc] init];
    model.userNick = @"userNick";
    model.collectionURL = @"collectionURL http://www.cocoachina.com/bbs/thread.php?fid-21-page-2.html";
    model.collectionTIME = @"collectionTIME 20181022";
    model.collectiontext = @"collectiontext 二狗子，下班啦";
    model.userID = 19931029;
//    model.tabId ; //插入数据库用不到
    
    [[PFFMDBManager sharemanager] insertDataWithModel:model];
    [[PFFMDBManager sharemanager] insertDataWithModel:model];
    [[PFFMDBManager sharemanager] insertDataWithModel:model];

    
    NSArray *arr =  [[PFFMDBManager sharemanager] queryAllDataWithUserID:19931029];
    
    NSLog(@"%@",arr);
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
