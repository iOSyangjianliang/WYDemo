//
//  PFFMDBManager.m
//  FMDB数据库使用
//
//  Created by 杨建亮 on 2018/5/22.
//  Copyright © 2018年 yangjianliang. All rights reserved.
//

#import "PFFMDBManager.h"
#import "FMDB.h"

#define TraDataPath [NSHomeDirectory() stringByAppendingString:@"/Documents/PFCollection"]

@interface PFFMDBManager ()
{
    FMDatabase *_dataBase;
    NSLock *_lock;
}
@end


@implementation PFFMDBManager
+ (PFFMDBManager*)sharemanager
{
    PFFMDBManager *manager;
    @synchronized (self) {
        manager =[[PFFMDBManager alloc]init];
    }
    return manager;
}
- (instancetype)init{
    if (self = [super init]) {
        [self creatDBTable];
        _lock = [[NSLock alloc]init];
    }
    return self;
}
#pragma mark - 创建表
-(void)creatDBTable
{
    //创建文件夹
    NSFileManager* fileManager = [NSFileManager defaultManager];
    [fileManager createDirectoryAtPath:TraDataPath withIntermediateDirectories:YES attributes:nil error:nil];
    
    //创建数据库
    NSString *dbPath = [TraDataPath stringByAppendingPathComponent:@"pfcollection.db"];
    _dataBase = [[FMDatabase alloc] initWithPath:dbPath];
    NSLog(@"%@",TraDataPath);
    
    [_dataBase open];
    //创建数据表，
    NSString *wuaisql = @"CREATE TABLE IF NOT EXISTS T_MyfmdbUserSql(ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,userNick TEXT,collectionURL TEXT,collectionTIME TEXT,collectiontext TEXT,userID TEXT)";
    if ([_dataBase executeUpdate:wuaisql]){
        NSLog(@"T_MyfmdbUserSql success");
        [_dataBase close];
    }else{
        [_dataBase close];
    }
}
#pragma mark - 插入数据
-(NSString *)insertDataWithModel:(Model *)model
{
    if ([_dataBase open]) {
        // 插入数据
        BOOL insertOK = [_dataBase executeUpdate:@"INSERT INTO T_MyfmdbUserSql(userNick,collectionURL,collectionTIME,collectiontext,userID) VALUES (?,?,?,?,?)",model.userNick,model.collectionURL,model.collectionTIME,model.collectiontext,[NSNumber numberWithInteger:model.userID]];
        if (insertOK) {
            NSLog(@"T_MyfmdbUserSql insert Success");
            
            long insertID = [_dataBase lastInsertRowId];//插入id
            [_dataBase close];
            return [NSString stringWithFormat:@"%ld",insertID];
        }else{
            NSLog(@"T_MyfmdbUserSql insert Fail");
            
            [_dataBase close];
            return nil;
        }
    }
    return nil;
}
#pragma mark - 删除数据，同时将数据插入删除数据表
-(void)deleteDataWithModel:(Model *)model
{
    if ([_dataBase open]) {
        NSString *delSQL = [NSString stringWithFormat:@"delete  from T_MyfmdbUserSql where ID = %ld",model.tabId];
        if ([_dataBase executeUpdate:delSQL]) {
            NSLog(@"T_MyfmdbUserSql delete Success");
        }else{
            NSLog(@"T_MyfmdbUserSql delete Fail");
        }
        [_dataBase close];
    }
}
#pragma mark - 获取某个用户ID对应所有数据
-(NSArray<__kindof Model *> *)queryAllDataWithUserID:(NSInteger)userID
{
    if ([_dataBase open]) {
        
        NSString *selSql = [NSString stringWithFormat:@"select * from T_MyfmdbUserSql where userID = %ld",userID];
        NSMutableArray* arrayM = [NSMutableArray array];
        FMResultSet *set = [_dataBase executeQuery:selSql];
        if (set != nil) {
            NSLog(@"T_MyfmdbUserSql query Success");
            while ([set next]) {
                Model *model = [[Model alloc] initWithSet:set];
                [arrayM addObject:model];
            }
            [set close];
            [_dataBase close];
            return arrayM;
        }
    }
    [_dataBase close];
    return [NSArray array];
}
@end
