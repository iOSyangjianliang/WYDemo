//
//  PFFMDBManager.h
//  FMDB数据库使用
//
//  Created by 杨建亮 on 2018/5/22.
//  Copyright © 2018年 yangjianliang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Model.h"

@interface PFFMDBManager : NSObject
+ (PFFMDBManager*)sharemanager;

-(NSString *)insertDataWithModel:(Model *)model;
-(void)deleteDataWithModel:(Model *)model;
-(NSArray<__kindof Model *> *)queryAllDataWithUserID:(NSInteger)userID;

@end
