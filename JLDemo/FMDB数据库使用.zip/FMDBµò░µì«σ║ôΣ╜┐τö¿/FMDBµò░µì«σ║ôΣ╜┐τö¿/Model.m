//
//  Model.m
//  FMDB数据库使用
//
//  Created by 杨建亮 on 2018/5/22.
//  Copyright © 2018年 yangjianliang. All rights reserved.
//

#import "Model.h"

@implementation Model
- (instancetype)initWithSet:(FMResultSet *)set
{
    if (self = [super init]) {
        
        self.tabId = [set intForColumnIndex:0];
        self.userNick = [set stringForColumn:@"userNick"];
        self.collectionURL = [set stringForColumn:@"collectionURL"] ;
        self.collectionTIME = [set stringForColumn:@"collectionTIME"] ;
        self.collectiontext = [set stringForColumn:@"collectiontext"] ;
        self.userID = [set intForColumn:@"userID"] ;
    }
    return self;
}
@end
